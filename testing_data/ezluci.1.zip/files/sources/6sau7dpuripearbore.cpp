#include <bits/stdc++.h>
//#define int long long
#pragma GCC optimize("O3")
#define pb push_back
#define MOD 1000000007
#define f first
#define s second
using namespace std;

int n , m;
vector <vector <int>> a;
vector < vector <vector <int>>> cost;

int dx[] = {1, 0, -1, 0};
int dy[] = {0, 1, 0, -1};
char dir[] = {'S', 'E', 'N', 'V'};

// state 4 (twin tower (single)), 0 -> 3 blocul curent + dx dy atachment

struct state {
    int x, y;
    int form;
};

bool inmat (int x, int y) {
    if (1 <= x && x <= n && 1 <= y && y <= m && a[x][y] == 0) return true;
    return false;
}

bool inmat (int x, int y, int form) {
    if (!inmat (x, y)) return false;
    if (form == 4) return true;
    x = x + dx[form];
    y = y + dy[form];
    if (inmat (x, y)) return true;
    return false;
}

signed main() {
    ios_base::sync_with_stdio(false);
    cin.tie(0);

    cin >> n >> m;
    a.resize(n + 2, vector <int> (m + 2, 0));
    cost.resize(n + 2, vector <vector <int>>(m + 2, vector <int> (5, 1e9)));
    int s1, s2, e1, e2;

    for (int i = 1;i <= n;i++) {
        for (int j = 1;j <= m;j++) {
            char c; cin >> c;
            if (c == 'A') {
                s1 = i; s2 = j;
            } else if (c == 'B') {
                e1 = i; e2 = j;
            } else if (c == '#') {
                a[i][j] = 1;
            }
        }
    }

    cost[s1][s2][4] = 0;
    state aux = {s1, s2, 4};
    queue <state> q;
    q.push(aux);

    while (!q.empty()) {
        aux = q.front();
        auto [x, y, form] = aux;
        q.pop();

        if (form == 4) {
            for (int d = 0 ; d < 4 ; d++) {
                int nx = x + dx[d];
                int ny = y + dy[d];
                if (inmat (nx, ny, d) && cost[nx][ny][d] > cost[x][y][4] + 1) {
                    cost[nx][ny][d] = cost[x][y][4] + 1;
                    q.push ({nx, ny, d});
                }
            }
            continue;
        }

        for (int d = 0 ; d < 4 ; d++) {
            int nx = x + dx[d];
            int ny = y + dy[d];
            if (d == form) {
                nx += dx[d];
                ny += dy[d];
            }

            int newform = form;
            if (d == form) newform = 4;
            if (d == (form + 2) % 4) newform = 4;

            if (inmat(nx, ny, newform) && cost[nx][ny][newform] > cost[x][y][form] + 1) {
                cost[nx][ny][newform] = cost[x][y][form] + 1;
                q.push ({nx, ny, newform});
            }
        }
    }

    if (cost[e1][e2][4] == 1e9) {
        cout << "NU\n";
        return 0;
    }

    vector <int> ans;
    int x = e1, y = e2;
    int form = 4;

    for (int i = cost[e1][e2][4]; i > 0; i--) {
        if (form == 4) {
            bool done = false;
            for (int d = 0; d < 4; d++) {
                int nx = x - 2 * dx[d];
                int ny = y - 2 * dy[d];

                if (inmat(nx, ny, d) && cost[nx][ny][d] == i - 1) {
                    ans.pb(d);
                    x = nx; y = ny;
                    form = d;

                    done = true;
                    break;
                }
            }

            if (done) continue;

            for (int d = 0; d < 4; d++) {
                int nx = x - dx[d];
                int ny = y - dy[d];
                int newform = (d + 2) % 4;

                if (inmat(nx, ny, newform) && cost[nx][ny][newform] == i - 1) {
                    ans.pb(d);
                    x = nx; y = ny;
                    form = newform;
                    break;
                }
            }
            continue;
        }

        for (int d = 0 ; d < 4 ; d++) {
            int nx = x + dx[d];
            int ny = y + dy[d];
            int newform;

            if (d == form) continue;
            if (d == (form + 2) % 4) newform = 4;
            else newform = form;

            if (inmat(nx, ny, newform) && cost[nx][ny][newform] == i - 1) {
                ans.pb((d + 2) % 4);
                x = nx, y = ny;
                form = newform;
                break;
            }
        }

    }

    cout << "DA\n" ;
    //cout << cost[e1][e2][4] << "\n";
    reverse(ans.begin(), ans.end());
    for (auto step : ans) cout << dir[step] ;
    cout << "\n";

    return 0;
}