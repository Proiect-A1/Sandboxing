#include <bits/stdc++.h>

using namespace std;
const int MAX = 2000;
char mr[MAX + 2][MAX + 2];
short deql[3 * MAX * MAX + 2], deqc[3 * MAX * MAX + 2];
char stare[3 * MAX * MAX + 2], v[3 * MAX * MAX + 2];
char dp[MAX + 2][MAX + 2][3], mut[MAX + 2][MAX + 2][3];
int prec[MAX + 2][MAX + 2][3];//tin unde eram in momentul precedent ca as putea reconstitui din mutare dar ar fi multe cazuri
//ca sa nu mai tin linia si coloana si starae voi tine pozitia din deque
int pr, ul, n, m;
void adaug(int l, int c, int s, char ch) {
    dp[l][c][s] = 1;
    deql[ul] = l;
    deqc[ul] = c;
    stare[ul] = s;
    ul++;
    prec[l][c][s] = pr;
    mut[l][c][s] = ch;
}
void verif0(int l, int c, char ch) {
    if (mr[l][c] != '#' && dp[l][c][0] == 0) {
        adaug(l, c, 0, ch);
    }
}
void verif1(int l, int c, char ch) {
    if (l <= n && l > 1 && mr[l][c] != '#' && mr[l - 1][c] != '#' && dp[l][c][1] == 0) {
        adaug(l, c, 1, ch);
    }
}
void verif2(int l, int c, char ch) {
    if (c <= m && c > 1 && mr[l][c] != '#' && mr[l][c - 1] != '#' && dp[l][c][2] == 0) {
        adaug(l, c, 2, ch);
    }
}
int main()
{
    //voi face un lee cu 3 stari
    //0 - sunt pe l, c si am inaltime 2
    //1 - sunt pe l, c si mai sunt si pe l - 1, c
    //2 - sunt pe l, c si mai sunt si pe l, c - 1
    int l, c, lin, col, pas, rez, x, s, nr;
    scanf("%d%d", &n, &m);
    pr = ul = lin = col = 0;
    for (l = 1; l <= n; l++) {
        scanf(" ");
        for (c = 1; c <= m; c++) {
            mr[l][c] = fgetc(stdin);
            //dp[l][c][0] = dp[l][c][1] = dp[l][c][2] = 0;
            if (mr[l][c] == 'A') {
                deql[ul] = l;
                deqc[ul] = c;
                stare[ul] = 0;
                ul++;
                dp[l][c][0] = 1;//dp este doar o frecventa daca am ajuns acolo in lee sau nu
                //puteam sa tin si numarul minim de pasi dar ar fi consumat mai multa memorie
            } else if (mr[l][c] == 'B') {
                lin = l;
                col = c;
            }
        }
    }
    //bordez cu perete
    for (l = 0; l <= n + 1; l++) {
        mr[l][0] = mr[l][m + 1] = '#';
    }
    for (c = 0; c <= m + 1; c++) {
        mr[0][c] = mr[n + 1][c] = '#';
    }
    pas = 1;
    rez = -1;
    while (pr < ul) {
        x = ul;
        while (pr < x) {
            l = deql[pr];
            c = deqc[pr];
            //nu cred ca pot sa fac cu vectori de directie
            if (stare[pr] == 0) {
                if (l == lin && c == col) {//am gasit rezultatul
                    rez = pas;
                    pr = ul;
                } else {
                    //in sus
                    verif1(l - 1, c, 'N');
                    //in jos
                    verif1(l + 2, c, 'S');
                    //in stanga
                    verif2(l, c - 1, 'V');
                    //in dreapta
                    verif2(l, c + 2, 'E');
                }
            } else if (stare[pr] == 1) {
                //in sus
                verif0(l - 2, c, 'N');
                //in jos
                verif0(l + 1, c, 'S');
                //in stanga
                verif1(l, c - 1, 'V');
                //in dreapta
                verif1(l, c + 1, 'E');
            } else {
                //in sus
                verif2(l - 1, c, 'N');
                //in jos
                verif2(l + 1, c, 'S');
                //in stanga
                verif0(l, c - 2, 'V');
                //in dreapta
                verif0(l, c + 1, 'E');
            }
            pr++;
        }
        pas++;
    }
    //si am gasit in numar minim de pasi
    if (rez == -1) {
        printf("NU\n");
    } else {
        printf("DA\n");
        s = nr = 0;
        do {
            v[nr] = mut[lin][col][s];
            nr++;
            pr = prec[lin][col][s];
            lin = deql[pr];
            col = deqc[pr];
            s = stare[pr];
        } while (pr != 0);
        //le am invers deci afisez vectorul invers
        for (nr--; nr >= 0; nr--) {
            fputc(v[nr], stdout);
        }
        fputc('\n', stdout);
    }
    return 0;
}