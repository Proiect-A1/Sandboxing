#include <bits/stdc++.h>
using namespace std;

// pentru aceasta problema, definim 5 stari posibile ale unui punct: una verticala, si 4 orizontale de la 0 la 3.
// starea orizontala 0 pentru punctul (i, j) se refera la punctele (i, j) si (i+DIR_I[0], j+DIR_J[0]).
// .....
// starea orizontala 3 pentru punctul (i, j) se refera la punctele (i, j) si (i+DIR_I[3], j+DIR_J[3]).
// de asemenea, starea verticala a unui punct o consideram 4.

const int nMAX = 2e3;
const int mMAX = 2e3;
const int DIR_I[4] = {-1, 0, 1, 0}; // N, E, S, V
const int DIR_J[4] = {0, 1, 0, -1}; // N, E, S, V
const int STARE_NOUA[5][4] = { // STARE_NOUA[i][j] = starea pe care o obtinem daca din starea i folosim directia j.
   {4, 0, 4, 0},
   {1, 4, 1, 4},
   {4, 2, 4, 2},
   {3, 4, 3, 4},
   {0, 1, 2, 3}
};
const pair<int, int> DIR_NOUA[5][4] = { // DIR_NOUA[i][j] = diferenta de pozitie daca din starea i folosim directia j.
   {{-2,0}, {0,1}, {1,0}, {0,-1}},
   {{-1,0}, {0,2}, {1,0}, {0,-1}},
   {{-1,0}, {0,1}, {2,0}, {0,-1}},
   {{-1,0}, {0,1}, {1,0}, {0,-2}},
   {{-1,0}, {0,1}, {1,0}, {0,-1}}
};


int n, m;
pair<int, int> a, b;
char mat[nMAX + 2][mMAX + 2];
bool aj[5][nMAX + 1][nMAX + 1]; // aj[k][i][j] = 1 daca putem ajunge din punctul A vertical, in punctul (i,j) cu starea k.
int lastDir[5][nMAX + 1][nMAX + 1];


int dirInversa(int dir)
{
   if (dir == 0)   return 2;
   if (dir == 1)   return 3;
   if (dir == 2)   return 0;
   if (dir == 3)   return 1;
}

void bordare()
{
   for (int i = 0; i <= n+1; ++i)
      mat[i][0] = mat[i][m+1] = '#';
   for (int j = 1; j <= m; ++j)
      mat[0][j] = mat[n+1][j] = '#';
}

bool BlockOk(int i, int j, int stare) // !!!! aceasta functie verifica daca blocul se afla pe # sau nu !!!!
{
   if ( !(1 <= i && i <= n && 1 <= j && j <= m) )
      return false;
   
   if (mat[i][j] == '#')
      return false;
   
   if (stare <= 3)
      if (mat[i + DIR_I[stare]][j + DIR_J[stare]] == '#')
         return false;
   
   return true;
}

void lee(int i, int j)
{
   queue<tuple<int, int, int>> q; // <i, j, stare 0..4>
   int stare;

   q.push(make_tuple(i, j, 4));
   aj[4][i][j] = 1;
   while (!q.empty())
   {
      tie(i, j, stare) = q.front();
      q.pop();

      if (stare == 4 && i == b.first && j == b.second)
         return;

      for (int dir = 0; dir < 4; ++dir)
      {
         int inou = i + DIR_NOUA[stare][dir].first;
         int jnou = j + DIR_NOUA[stare][dir].second;
         int starenou = STARE_NOUA[stare][dir];

         if (BlockOk(inou, jnou, starenou) && aj[starenou][inou][jnou] == 0)
         {
            aj[starenou][inou][jnou] = 1;
            lastDir[starenou][inou][jnou] = dir;
            if (starenou <= 3)
            {
               aj[dirInversa(starenou)][inou + DIR_I[starenou]][jnou + DIR_J[starenou]] = 1;
               lastDir[dirInversa(starenou)][inou + DIR_I[starenou]][jnou + DIR_J[starenou]] = dir;
            }

            q.push(make_tuple(inou, jnou, starenou));
         }
      }
   }
}


void afisDrum(int i, int j, int stare)
{
   if (i == a.first && j == a.second && stare == 4)
      return;
   
   int dir = lastDir[stare][i][j];
   int dirrev = dirInversa(dir);
   afisDrum(i + DIR_NOUA[stare][dirrev].first, j + DIR_NOUA[stare][dirrev].second, STARE_NOUA[stare][dirrev]);

   if (dir == 0)  cout << 'N';
   else if (dir == 1)   cout << 'E';
   else if (dir == 2)   cout << 'S';
   else if (dir == 3)   cout << 'V';
   else  cout << '?';
}


int main()
{
   cin >> n >> m;
   for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= m; ++j)
      {
         cin >> mat[i][j];
         if (mat[i][j] == 'A')
         {
            a = make_pair(i, j);
            mat[i][j] = '_';
         }
         else if (mat[i][j] == 'B')
         {
            b = make_pair(i, j);
            mat[i][j] = '_';
         }
      }
   
   bordare();
   lee(a.first, a.second);

   if (aj[4][b.first][b.second])
   {
      cout << "DA\n";
      afisDrum(b.first, b.second, 4);
   }
   else
   {
      cout << "NU\n";
   }
}