#include <bits/stdc++.h>

using namespace std;
const int MAX = 2000;
const int INF = 1e9;
char mr[MAX + 2][MAX + 2];
int deql[MAX * MAX + 2], deqc[MAX * MAX + 2], stare[MAX * MAX + 2];
char dp[MAX + 2][MAX + 2][3], mut[MAX + 2][MAX + 2][3];//short si char
int pr, ul, n, m;
void verif0(int l, int c) {
    if (l > 0 && l <= n && c > 0 && c <= m && mr[l][c] != '#' && dp[l][c][0] == 0) {
        dp[l][c][0] = 1;
        deql[ul] = l;
        deqc[ul] = c;
        stare[ul] = 0;
        ul++;
    }
}
void verif1(int l, int c) {
    if (l <= n && l > 1 && c > 0 && c <= m && mr[l][c] != '#' && mr[l - 1][c] != '#' && dp[l][c][1] == 0) {
        dp[l][c][1] = 1;
        deql[ul] = l;
        deqc[ul] = c;
        stare[ul] = 1;
        ul++;
    }
}
void verif2(int l, int c) {
    if (c <= m && c > 1 && l > 0 && l <= n && mr[l][c] != '#' && mr[l][c - 1] != '#' && dp[l][c][2] == 0) {
        dp[l][c][2] = 1;
        deql[ul] = l;
        deqc[ul] = c;
        stare[ul] = 2;
        ul++;
    }
}
int main()
{
    //voi face un lee cu 3 stari
    //0 - sunt pe l, c si am inaltime 2
    //1 - sunt pe l, c si mai sunt si pe l - 1, c
    //2 - sunt pe l, c si mai sunt si pe l, c - 1
    int l, c, lin, col, pas, rez, x;
    scanf("%d%d", &n, &m);
    pr = ul = lin = col = 0;
    for (l = 1; l <= n; l++) {
        scanf(" ");
        for (c = 1; c <= m; c++) {
            mr[l][c] = fgetc(stdin);
            //dp[l][c][0] = dp[l][c][1] = dp[l][c][2] = 0;
            if (mr[l][c] == 'A') {
                deql[ul] = l;
                deqc[ul] = c;
                stare[ul] = 0;
                ul++;
                dp[l][c][0] = 1;//dp este doar o frecventa daca am ajuns acolo in lee sau nu
                //puteam sa tin si numarul minim de pasi dar ar fi consumat mai multa memorie
            } else if (mr[l][c] == 'B') {
                lin = l;
                col = c;
            }
        }
    }
    //bordez cu perete
    for (l = 0; l <= n + 1; l++) {
        mr[l][0] = mr[l][m + 1] = '#';
    }
    for (c = 0; c <= m + 1; c++) {
        mr[0][c] = mr[n + 1][c] = '#';
    }
    pas = 1;
    rez = -1;
    while (pr < ul) {
        x = ul;
        while (pr < x) {
            l = deql[pr];
            c = deqc[pr];
            //nu cred ca pot sa fac cu vectori de directie
            if (stare[pr] == 0) {
                if (l == lin && c == col) {//am gasit rezultatul
                    rez = pas;
                    pr = ul;
                } else {
                    //in sus
                    verif1(l - 1, c);
                    //in jos
                    verif1(l + 2, c);
                    //in stanga
                    verif2(l, c - 1);
                    //in dreapta
                    verif2(l, c + 2);
                }
            } else if (stare[pr] == 1) {
                //in sus
                verif0(l - 2, c);
                //in jos
                verif0(l + 1, c);
                //in stanga
                verif1(l, c - 1);
                //in dreapta
                verif1(l, c + 1);
            } else {
                //in sus
                verif2(l - 1, c);
                //in jos
                verif2(l + 1, c);
                //in stanga
                verif0(l, c - 2);
                //in dreapta
                verif0(l, c + 1);
            }
            pr++;
        }
        pas++;
    }
    if (rez == -1) {
        printf("NU\n");
    } else {
        printf("DA\n");
    }
    return 0;
}