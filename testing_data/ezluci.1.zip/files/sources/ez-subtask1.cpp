#include <bits/stdc++.h>
#define fi first
#define se second
using namespace std;


const int nMAX = 2e3;
const int mMAX = 2e3;

int n, m;
pair<int, int> a, b;
char mat[nMAX + 2][mMAX + 2];


int main()
{
   cin >> n >> m;
   for (int i = 1; i <= n; ++i)
      for (int j = 1; j <= m; ++j)
      {
         cin >> mat[i][j];
         if (mat[i][j] == 'A')
         {
            a = make_pair(i, j);
            mat[i][j] = '_';
         }
         else if (mat[i][j] == 'B')
         {
            b = make_pair(i, j);
            mat[i][j] = '_';
         }
      }
   
   if (a.fi % 3 != b.fi % 3 || a.se % 3 != b.se % 3)
      cout << "NU",  exit(0);
   
   // aceasta este parcurgere in linie dreapta, daca gasim un # atunci NU
   for (int i = min(a.fi, b.fi); i <= max(a.fi, b.fi); ++i)
      for (int j = min(a.se, b.se); j <= max(a.se, b.se); ++j)
         if (mat[i][j] == '#')
            cout << "NU",  exit(0);

   int cnt = (abs(a.fi-b.fi) + abs(a.se-b.se)) / 3 * 2;
   cout << "DA\n" << string(cnt, (a.fi<b.fi ? 'S' : a.fi>b.fi ? 'N' : a.se<b.se ? 'E' : 'V'));
}