#include "problem.h"
#include<bits/stdc++.h>

using namespace std;

// complet la misto (ca sa mearga (cred))
int main(int argc, char** argv){
    validator inf;
    return 0;
}
