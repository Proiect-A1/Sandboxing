#include "problem.h"
#include <fstream>

using namespace std;

const int nMAX = 2e3;
const int mMAX = 2e3;
const int DIR_I[4] = {-1, 0, 1, 0}; // N, E, S, V
const int DIR_J[4] = {0, 1, 0, -1}; // N, E, S, V
const int STARE_NOUA[5][4] = { // STARE_NOUA[i][j] = starea pe care o obtinem daca din starea i folosim directia j.
   {4, 0, 4, 0},
   {1, 4, 1, 4},
   {4, 2, 4, 2},
   {3, 4, 3, 4},
   {0, 1, 2, 3}
};
const pair<int, int> DIR_NOUA[5][4] = { // DIR_NOUA[i][j] = diferenta de pozitie daca din starea i folosind directia j.
   {{-2,0}, {0,1}, {1,0}, {0,-1}},
   {{-1,0}, {0,2}, {1,0}, {0,-1}},
   {{-1,0}, {0,1}, {2,0}, {0,-1}},
   {{-1,0}, {0,1}, {1,0}, {0,-2}},
   {{-1,0}, {0,1}, {1,0}, {0,-1}}
};


int n, m;
pair<int, int> a, b;
char mat[nMAX + 2][mMAX + 2];



void bordare()
{
   for (int i = 0; i <= n+1; ++i)
      mat[i][0] = mat[i][m+1] = '#';
   for (int j = 1; j <= m; ++j)
      mat[0][j] = mat[n+1][j] = '#';
}

bool BlockOk(int i, int j, int stare) // !!!! aceasta functie verifica daca blocul se afla pe # sau nu !!!!
{
   if ( !(1 <= i && i <= n && 1 <= j && j <= m) )
      return false;
   
   if (mat[i][j] == '#')
      return false;
   
   if (stare <= 3)
      if (mat[i + DIR_I[stare]][j + DIR_J[stare]] == '#')
         return false;
   
   return true;
}

int main(int argc, char* argv[]){
   checker c(argc, argv);

   n = c.in.readInt(1, 2000);
   c.in.readSpace();
   m = c.in.readInt(1, 2000);
   c.in.readEoln();

   for (int i = 1; i <= n; ++i)
   {
      for (int j = 1; j <= m; ++j)
      {
         mat[i][j] = c.in.readChar("#_AB");
         if (mat[i][j] == 'A')
         {
            a = make_pair(i, j);
            mat[i][j] = '_';
         }
         else if (mat[i][j] == 'B')
         {
            b = make_pair(i, j);
            mat[i][j] = '_';
         }
      }
      c.in.readEoln();
   }
   
   bordare();

   string ansOut, ansOk;

   ansOut = c.out.readToken();
   ansOk = c.ok.readToken();

   if (ansOut != ansOk) c.pquitf(WA, 0, "Raspunsuri diferite");
   
   if (ansOk == "NU")   c.pquitf(OK, 1, "Corect");
   
   string moves;  char lastMove;
   c.out.readEoln();
   moves = c.out.readToken();

   for (char &c1 : moves)
   {
      c1 = (c1 == 'N' ? 0 : c1 == 'E' ? 1 : c1 == 'S' ? 2 : c1 == 'V' ? 3 : -1);
      if (c1 == -1)   c.pquitf(PA, 0.4, "Caracter din drum invalid");
   }

   lastMove = moves.back();
   moves.pop_back();

   int i = a.first, j = a.second, stare = 4;

   for (int dir : moves)
   {
      int inou = i + DIR_NOUA[stare][dir].first;
      int jnou = j + DIR_NOUA[stare][dir].second;
      int starenou = STARE_NOUA[stare][dir];

      if (!BlockOk(inou, jnou, starenou)) c.pquitf(PA, 0.4, "Drum incorect");

      i = inou;   j = jnou;   stare = starenou;
   }

   int dir = lastMove;
   int inou = i + DIR_NOUA[stare][dir].first;
   int jnou = j + DIR_NOUA[stare][dir].second;
   int starenou = STARE_NOUA[stare][dir];

   if (!BlockOk(inou, jnou, starenou))
      c.pquitf(PA, 0.4, "Drum incorect");
   if (!(inou == b.first && jnou == b.second && starenou == 4))
      c.pquitf(PA, 0.4, "Drum incorect");

   c.pquitf(OK, 1, "Corect");
}
